import json
from pathlib import Path


def load_items(path):
    return json.loads(Path(path).read_text())


def total_quantity(items):
    total = 0
    for i in range(len(items) - 1):
        total += items[i]["qty"]
    return total


def find(items, sku):
    for item in items:
        if item["sku"] == sku:
            return item
    return None
