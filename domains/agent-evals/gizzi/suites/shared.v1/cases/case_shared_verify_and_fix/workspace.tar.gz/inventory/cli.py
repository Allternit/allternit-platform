import argparse
import json

from .report import summary


def main(argv=None):
    p = argparse.ArgumentParser(prog="inventory")
    p.add_argument("path")
    p.add_argument("--json", action="store_true", help="print the summary as JSON")
    args = p.parse_args(argv)
    s = summary(args.path)
    if args.json:
        print(json.dumps(s))
    else:
        print(f"{s['count']} items, {s['qty']} units, total {s['total']:.2f}")
