import unittest

from inventory.pricing import order_total

ITEMS = [{"sku": "a", "qty": 2, "price": 1.0}, {"sku": "b", "qty": 3, "price": 2.0}]


class PricingTest(unittest.TestCase):
    def test_order_total(self):
        self.assertEqual(order_total(ITEMS), 8.0)
