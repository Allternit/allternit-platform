import unittest

from inventory.store import find, total_quantity

ITEMS = [{"sku": "a", "qty": 2, "price": 1.0}, {"sku": "b", "qty": 3, "price": 2.0}]


class StoreTest(unittest.TestCase):
    def test_total_quantity(self):
        self.assertEqual(total_quantity(ITEMS), 5)

    def test_find(self):
        self.assertEqual(find(ITEMS, "b")["qty"], 3)
        self.assertIsNone(find(ITEMS, "z"))
