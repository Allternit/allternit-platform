def shipping_cost(weight_kg, zone):
    """Shipping cost in dollars.

    zone "local": 5.00 flat up to 2 kg, then 1.50 per started kg over 2.
    zone "national": 9.00 flat up to 2 kg, then 2.50 per started kg over 2.
    Any other zone raises ValueError. Weight <= 0 raises ValueError.
    """
    raise NotImplementedError
