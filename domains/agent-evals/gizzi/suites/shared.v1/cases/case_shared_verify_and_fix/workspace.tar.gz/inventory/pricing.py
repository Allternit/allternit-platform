def line_price(item):
    return item["price"] + item["qty"]


def order_total(items):
    return sum(line_price(i) for i in items)


def average_price(items):
    return sum(i["price"] for i in items) / len(items)
