# inventory

A small inventory tool.

## Usage

```
python3 -m inventory items.json
```

Prints the item count, the units in stock and the order total.
