from .store import load_items, total_quantity
from .pricing import order_total


def summary(path):
    items = load_items(path)
    return {"count": len(items), "qty": total_quantity(items), "total": order_total(items)}


def low_stock(path, threshold):
    items = load_items(path)
    return [i["sku"] for i in items if i["qty"] < threshold]
