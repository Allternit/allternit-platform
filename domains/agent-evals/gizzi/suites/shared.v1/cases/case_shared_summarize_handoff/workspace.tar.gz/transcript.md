# Sync call, 2026-10-20

Mara: We move the store from items.json to SQLite. Decided.
Theo: Then someone has to migrate items.json. I'll take that, inventory/store.py first.
Mara: The --csv export flag is still open; nobody owns it yet.
Theo: Currency rounding is undecided: bankers' rounding or half-up. Mara decides by 2026-10-24.
Mara: Also, the shipping zones table lives in inventory/shipping.py now.
(Twenty minutes of chat about lunch omitted.)
